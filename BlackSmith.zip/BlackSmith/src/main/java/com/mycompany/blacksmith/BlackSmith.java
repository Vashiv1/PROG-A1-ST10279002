/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.blacksmith;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */

public class BlackSmith {

    public static void main(String[] args) {
    int numberOfDays;//declare variables
  
  
 
           
    Scanner kb=new Scanner(System.in);
    
            System.out.println("Please enter number of days");// prompting user for value 
            numberOfDays=kb.nextInt();// input number of days 
            
    numberOfDays(numberOfDays);//calling method
            
    }
            public static void numberOfDays(int numberOfDays){
                int daggerPairs;//declare variables
                int modDaggerPairs;
                int finalDaggers;
             
                
                finalDaggers=numberOfDays*3;//final amount of daggers the *3 is how much the blacksmith can make in a day
                daggerPairs=finalDaggers/2;// final amount of dagger pairs 
                  modDaggerPairs=finalDaggers%2;// left over daggers resulting from it not being in a pair
                    
                   System.out.println(finalDaggers+" Dagger(s) results in "+daggerPairs+" pairs "+ "and with "+modDaggerPairs+" left over.");// final result 
            }      
    }

