/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pay;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class Pay {

    public static void main(String[] args) {
       //declaring employee variables 
      double hoursWorked;
      double hourlyRate;
      
    
   //instanating object to be called 
      Scanner kb=new Scanner(System.in);
      
      
      // hourly rate input
        System.out.println("Please enter hourly rate ");
        hourlyRate=kb.nextDouble();
     
      //hours the are worked input
        System.out.println("please enter hours worked ");
        
        hoursWorked=kb.nextDouble();

        
        EmployeePay(hoursWorked, hourlyRate);//calling method
        System.out.println("An employee who makes R"+ hourlyRate+" per hour");//output for hourly rate 
        System.out.println("and works "+hoursWorked+" hours");//hours worked output
        System.out.println("earns R"+EmployeePay(hoursWorked, hourlyRate)+" in a week");
        
    }
    public static double EmployeePay(double hoursWorked, double hourlyRate){
       
        double hours;
        hours=hoursWorked*hourlyRate;//calculation is done over here 
        
        return hours;
    }
            
}
