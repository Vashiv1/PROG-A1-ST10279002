/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registrationandpasswordfinal;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author lab_services_student
 */
public class LoginClass {
//declare variables

    String CheckUsername;
    String CheckPasswordComplexity;
    boolean CheckUsername1;
    boolean CheckPasswordComplexity1;
    String RegUsername;
    String RegPassword;
    boolean RegUsername1;
    boolean RegPassword1;
    String regex = "^(?=.*\\d)(?=.*[A-Z])(?=.*[@#&$%!]).{7,}$"; //password must contain these characters
    String firstName;
    String surName;

    public String getSurName() {
        return surName;
    }

    public void setSurName(String surName) {
        this.surName = surName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public boolean isRegUsername1() {
        //checks if usernames are equal
        return (RegUsername.equals(CheckUsername));
    }

    public void setRegUsername1(boolean RegUsername1) {
        this.RegUsername1 = RegUsername1;
    }

    public boolean isRegPassword1() {
        //checks if passwords are equal
        return (RegPassword.equals(CheckPasswordComplexity));
    }

    public void setRegPassword1(boolean RegPassword1) {
        this.RegPassword1 = RegPassword1;
    }

    public String getRegPassword() {
        return RegPassword;
    }

    public void setRegPassword(String RegPassword) {
        this.RegPassword = RegPassword;
    }

    public String getRegUsername() {
        return RegUsername;
    }

    public void setRegUsername(String RegUsername) {
        this.RegUsername = RegUsername;
    }

    public boolean isCheckPasswordComplexity1() {

        //password must contain these characters
        return CheckPasswordComplexity1 = isValidPassword(CheckPasswordComplexity, regex);
    }

    public void setCheckPasswordComplexity1(boolean CheckPasswordComplexity1) {
        this.CheckPasswordComplexity1 = CheckPasswordComplexity1;
    }

    public String getCheckUsername() {
        return CheckUsername;
    }

    public void setCheckUsername(String CheckUsername) {
        this.CheckUsername = CheckUsername;
    }

    public boolean isCheckUsername1() {
        //username must contain these characters
        return CheckUsername.contains("_") && CheckUsername.length() < 6;

    }

    public void setCheckUsername1(boolean CheckUsername1) {
        this.CheckUsername1 = CheckUsername1;

    }

    public String getCheckPasswordComplexity() {
        return CheckPasswordComplexity;
    }

    public void setCheckPasswordComplexity(String CheckPasswordComplexity) {
        this.CheckPasswordComplexity = CheckPasswordComplexity;
    }

    public static boolean isValidPassword(String CheckPasswordComplexity, String regex) {
        Pattern pattern = Pattern.compile(regex);//matches it to regex to see if password is qualified to be registered 
        Matcher matcher = pattern.matcher(CheckPasswordComplexity);
        return matcher.matches();
    }

}
