/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.registrationandpasswordfinal;

import javax.swing.JOptionPane;

/**
 *
 * @author lab_services_student
 */
public class RegistrationAndPasswordFinal {

    public static void main(String[] args) {
        //declare variables
        String Username, password, checkUsername, checkPassword, firstName, secondName, returnLoginStatus;
        boolean passwordAndUsername;
        LoginClass logObj = new LoginClass();

        //names input
        firstName = JOptionPane.showInputDialog("Please enter your first name");
        logObj.setFirstName(firstName);
        JOptionPane.showMessageDialog(null, "First name captured");
        secondName = JOptionPane.showInputDialog("Please enter your surname");
        logObj.setSurName(secondName);
        JOptionPane.showMessageDialog(null, "Surname captured");
        //end of names input

        // start Username login class
        Username = JOptionPane.showInputDialog("Please register with a valid username. \nThe Username must be less than 5 characters and contain an underscore.");
        logObj.setCheckUsername(Username);

        System.out.println("Username correctly formatted>>" + logObj.isCheckUsername1());

        while (logObj.isCheckUsername1() != true) {
            Username = JOptionPane.showInputDialog("Username not correctly formatted,\n please ensure that your username contains an underscore\n and is no more than 5 characters in length ");
            logObj.setCheckUsername(Username);
            System.out.println("Username correctly formatted>>" + logObj.isCheckUsername1());
        }

        JOptionPane.showMessageDialog(null, "Username succesfully captured");

        //end of username login class 
        // Start of password Class
        password = JOptionPane.showInputDialog("Please enter a valid password\n It must be over 8 characters long\n It must contain a special character\n it must have a capital letter\n It must have a number");
        logObj.setCheckPasswordComplexity(password);

        System.out.println("Password correctly formatted>>" + logObj.isCheckPasswordComplexity1());
        while (logObj.isCheckPasswordComplexity1() != true) {
            password = JOptionPane.showInputDialog(null, "Password is not correctly formatted.\n please ensure that the password contains at least 8 characters,\na capital letter,\n a number and\n a special character. ");

            logObj.setCheckPasswordComplexity(password);
            System.out.println("Password correctly formatted>>" + logObj.isCheckPasswordComplexity1());

        }
        JOptionPane.showMessageDialog(null, "Password succesfully Captured");

        //end of password class
        //start of login class
        checkUsername = JOptionPane.showInputDialog(null, "Please enter login username you have registered with");
        logObj.setRegUsername(checkUsername);

        checkPassword = JOptionPane.showInputDialog(null, "Please enter password you have registered with");
        logObj.setRegPassword(checkPassword);

        //end of login class
        //start of password and username check identity
        passwordAndUsername = (logObj.isRegUsername1() == true && logObj.isRegPassword1() == true);//checks if password and username are false or true, it returns true if both condtions are met 
        while (!passwordAndUsername) {
            JOptionPane.showMessageDialog(null, "Username or password incorrect \n please try again");
            returnLoginStatus = "Failed login";
            System.out.println("Login status>>" + returnLoginStatus);
            checkUsername = JOptionPane.showInputDialog(null, "Please enter login username you have registered with");
            logObj.setRegUsername(checkUsername);

            checkPassword = JOptionPane.showInputDialog(null, "Please enter password you have registered with");
            logObj.setRegPassword(checkPassword);
            passwordAndUsername = (logObj.isRegUsername1() == true && logObj.isRegPassword1() == true);

        }

        //end of password check identity 
        //start of login class 
        JOptionPane.showMessageDialog(null, "Login successful");
        returnLoginStatus = "Succesful login";
        System.out.println("Login status>>" + returnLoginStatus);

        JOptionPane.showMessageDialog(null, "Welcome " + firstName + " " + secondName + "\n it is great to see you again");
        //end of login class 
    }

}
/*

Java While loop (2020) CodersLegacy. Siddiqi. Available at: https://coderslegacy.com/java/java-while-loop/ (Accessed: April 29, 2023).
Habibi, M. (2014) Java Regular Expressions. New York, NY: Springer.
Pattern (java platform SE 7 ) (2020) Oracle.com. Available at: https://docs.oracle.com/javase/7/docs/api/java/util/regex/Pattern.html (Accessed: April 29, 2023).





*/