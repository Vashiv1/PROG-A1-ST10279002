/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.registrationandpasswordfinal;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lab_services_student
 */
public class LoginClassTest {
    
    public LoginClassTest() {
    }

    /**
     * Test of getCheckUsername method, of class LoginClass.
     */
    @Test
    public void testGetCheckUsername() {
        System.out.println("getCheckUsername");
        LoginClass instance = new LoginClass();
        String expResult = "_kk";
        String result = instance.getCheckUsername();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCheckUsername method, of class LoginClass.
     */
    @Test
    public void testSetCheckUsername() {
        System.out.println("setCheckUsername");
        String CheckUsername = "_kyl";
        LoginClass instance = new LoginClass();
        instance.setCheckUsername(CheckUsername);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isCheckUsername1 method, of class LoginClass.
     */
    @Test
    public void testIsCheckUsername1() {
        System.out.println("isCheckUsername1");
        LoginClass instance = new LoginClass();
        boolean expResult = true;
        boolean result = instance.isCheckUsername1();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCheckUsername1 method, of class LoginClass.
     */
    @Test
    public void testSetCheckUsername1() {
        System.out.println("setCheckUsername1");
        boolean CheckUsername1 = false;
        LoginClass instance = new LoginClass();
        instance.setCheckUsername1(CheckUsername1);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCheckPasswordComplexity method, of class LoginClass.
     */
    @Test
    public void testGetCheckPasswordComplexity() {
        System.out.println("getCheckPasswordComplexity");
        LoginClass instance = new LoginClass();
        String expResult = "";
        String result = instance.getCheckPasswordComplexity();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCheckPasswordComplexity method, of class LoginClass.
     */
    @Test
    public void testSetCheckPasswordComplexity() {
        System.out.println("setCheckPasswordComplexity");
        String CheckPasswordComplexity = "";
        LoginClass instance = new LoginClass();
        instance.setCheckPasswordComplexity(CheckPasswordComplexity);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isRegUsername1 method, of class LoginClass.
     */
    @Test
    public void testIsRegUsername1() {
        System.out.println("isRegUsername1");
        LoginClass instance = new LoginClass();
        boolean expResult = false;
        boolean result = instance.isRegUsername1();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setRegUsername1 method, of class LoginClass.
     */
    @Test
    public void testSetRegUsername1() {
        System.out.println("setRegUsername1");
        boolean RegUsername1 = false;
        LoginClass instance = new LoginClass();
        instance.setRegUsername1(RegUsername1);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isRegPassword1 method, of class LoginClass.
     */
    @Test
    public void testIsRegPassword1() {
        System.out.println("isRegPassword1");
        LoginClass instance = new LoginClass();
        boolean expResult = false;
        boolean result = instance.isRegPassword1();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setRegPassword1 method, of class LoginClass.
     */
    @Test
    public void testSetRegPassword1() {
        System.out.println("setRegPassword1");
        boolean RegPassword1 = false;
        LoginClass instance = new LoginClass();
        instance.setRegPassword1(RegPassword1);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRegPassword method, of class LoginClass.
     */
    @Test
    public void testGetRegPassword() {
        System.out.println("getRegPassword");
        LoginClass instance = new LoginClass();
        String expResult = "";
        String result = instance.getRegPassword();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setRegPassword method, of class LoginClass.
     */
    @Test
    public void testSetRegPassword() {
        System.out.println("setRegPassword");
        String RegPassword = "";
        LoginClass instance = new LoginClass();
        instance.setRegPassword(RegPassword);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRegUsername method, of class LoginClass.
     */
    @Test
    public void testGetRegUsername() {
        System.out.println("getRegUsername");
        LoginClass instance = new LoginClass();
        String expResult = "";
        String result = instance.getRegUsername();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setRegUsername method, of class LoginClass.
     */
    @Test
    public void testSetRegUsername() {
        System.out.println("setRegUsername");
        String RegUsername = "";
        LoginClass instance = new LoginClass();
        instance.setRegUsername(RegUsername);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isCheckPasswordComplexity1 method, of class LoginClass.
     */
    @Test
    public void testIsCheckPasswordComplexity1() {
        System.out.println("isCheckPasswordComplexity1");
        LoginClass instance = new LoginClass();
        boolean expResult = false;
        boolean result = instance.isCheckPasswordComplexity1();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCheckPasswordComplexity1 method, of class LoginClass.
     */
    @Test
    public void testSetCheckPasswordComplexity1() {
        System.out.println("setCheckPasswordComplexity1");
        boolean CheckPasswordComplexity1 = false;
        LoginClass instance = new LoginClass();
        instance.setCheckPasswordComplexity1(CheckPasswordComplexity1);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
